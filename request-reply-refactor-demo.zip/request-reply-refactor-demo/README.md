# request-reply-refactor-demo

Минимальный пример рефакторинга текущей схемы:

REST -> Redis queue -> Scheduler -> Kafka -> Requisition service -> Kafka -> Redis by correlationId -> polling -> REST.

## Модули

- `common` — `RequestEnvelope`, `ResponseEnvelope`, `RequestHandler`, `RequestHandlerResolver`.
- `rest-service` — `RequestSender`, `RequestReplyService`, listener ответа.
- `requisition-service` — `PreparedRequestService`, `PreparedRequest`, `RequestHandlerExecutor`, пример `PendingCandidatesHandler`.

## Основная идея на принимающем сервисе

`PreparedRequestService.prepare()` выполняет всю общую часть, которая раньше находилась до `switch`:

1. deserialize `RequestEnvelope<JsonNode>`;
2. restore из filestorage по `fileUuid`;
3. create `SapSystemParamsDto`;
4. set `RequestContext`;
5. logging;
6. save request entity;
7. enrich roles;
8. enrich tab number.

После этого `RequestHandlerExecutor` выбирает handler по `requestType`, превращает `JsonNode` в конкретный request DTO и вызывает UseCase.

Это демонстрационный каркас: интеграции Redis/Kafka/DB/filestorage представлены интерфейсами и должны быть подключены к существующим реализациям проекта.
