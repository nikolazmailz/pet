package ru.ntdev.srhr.rest.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ru.ntdev.srhr.requestreply.model.RequestEnvelope;
import ru.ntdev.srhr.rest.redis.RedisAdapter;

public class RequestSender {
    private final ObjectMapper objectMapper;
    private final RedisAdapter redisAdapter;
    private final String requestQueue;

    public RequestSender(ObjectMapper objectMapper, RedisAdapter redisAdapter, String requestQueue) {
        this.objectMapper = objectMapper;
        this.redisAdapter = redisAdapter;
        this.requestQueue = requestQueue;
    }

    public <T> void send(RequestEnvelope<T> request) throws JsonProcessingException {
        String json = objectMapper.writeValueAsString(request);
        redisAdapter.putToQueue(requestQueue, json);
    }
}
