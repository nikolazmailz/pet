package ru.ntdev.srhr.requisition.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import ru.ntdev.srhr.requestreply.handler.RequestHandler;
import ru.ntdev.srhr.requestreply.handler.RequestHandlerResolver;
import ru.ntdev.srhr.requestreply.model.RequestEnvelope;
import ru.ntdev.srhr.requestreply.model.ResponseEnvelope;

public class RequestHandlerExecutor {
    private final ObjectMapper objectMapper;
    private final RequestHandlerResolver resolver;

    public RequestHandlerExecutor(ObjectMapper objectMapper, RequestHandlerResolver resolver) {
        this.objectMapper = objectMapper;
        this.resolver = resolver;
    }

    public ResponseEnvelope<?> execute(PreparedRequest<JsonNode> prepared) throws Exception {
        RequestHandler<?, ?, ?> handler = resolver.resolve(prepared.request().requestType());
        return executeTyped(prepared, handler);
    }

    @SuppressWarnings("unchecked")
    private <T, R> ResponseEnvelope<R> executeTyped(
            PreparedRequest<JsonNode> prepared,
            RequestHandler<?, ?, ?> rawHandler
    ) throws Exception {
        RequestHandler<T, R, PreparedRequest<T>> handler =
                (RequestHandler<T, R, PreparedRequest<T>>) rawHandler;

        T payload = objectMapper.treeToValue(prepared.payload(), handler.requestClass());

        RequestEnvelope<T> typedEnvelope = new RequestEnvelope<>(
                prepared.request().correlationId(),
                prepared.request().requestType(),
                prepared.request().sessionId(),
                prepared.request().adLogin(),
                prepared.request().traceId(),
                prepared.request().channel(),
                prepared.request().realm(),
                prepared.request().fileUuid(),
                payload
        );

        PreparedRequest<T> typed = new PreparedRequest<>(
                typedEnvelope,
                prepared.systemParams(),
                prepared.requestEntity(),
                prepared.startedAt()
        );

        R result = handler.handle(typed);
        return ResponseEnvelope.success(typedEnvelope.correlationId(), typedEnvelope.requestType(), result);
    }
}
