package ru.ntdev.srhr.requisition.service;

import ru.ntdev.srhr.requestreply.model.RequestEnvelope;
import ru.ntdev.srhr.requisition.domain.RequisitionRequestEntity;
import ru.ntdev.srhr.requisition.domain.SapSystemParamsDto;

public record PreparedRequest<T>(
        RequestEnvelope<T> request,
        SapSystemParamsDto systemParams,
        RequisitionRequestEntity requestEntity,
        long startedAt
) {
    public T payload() {
        return request.payload();
    }
}
