package ru.ntdev.srhr.requisition.domain;

public record ActorRoleDto(String roleId) {
}
