package ru.ntdev.srhr.requisition.handler;

import ru.ntdev.srhr.requestreply.handler.RequestHandler;
import ru.ntdev.srhr.requisition.service.PreparedRequest;
import ru.ntdev.srhr.requisition.usecase.PendingCandidatesRequest;
import ru.ntdev.srhr.requisition.usecase.PendingCandidatesResponse;
import ru.ntdev.srhr.requisition.usecase.PendingCandidatesUseCase;

public class PendingCandidatesHandler implements RequestHandler<
        PendingCandidatesRequest,
        PendingCandidatesResponse,
        PreparedRequest<PendingCandidatesRequest>> {

    private final PendingCandidatesUseCase useCase;

    public PendingCandidatesHandler(PendingCandidatesUseCase useCase) {
        this.useCase = useCase;
    }

    @Override
    public String requestType() {
        return "requisition_pending_candidates";
    }

    @Override
    public Class<PendingCandidatesRequest> requestClass() {
        return PendingCandidatesRequest.class;
    }

    @Override
    public PendingCandidatesResponse handle(PreparedRequest<PendingCandidatesRequest> context) {
        return useCase.execute(context.systemParams(), context.payload());
    }
}
