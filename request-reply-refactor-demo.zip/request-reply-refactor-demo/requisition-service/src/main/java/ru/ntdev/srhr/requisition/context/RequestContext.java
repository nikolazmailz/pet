package ru.ntdev.srhr.requisition.context;

public record RequestContext(String adLogin, String sessionId, String channel) {
}
