package ru.ntdev.srhr.requisition.usecase;

public record PendingCandidatesResponse(long count) {
}
