package ru.ntdev.srhr.requisition.domain;

import java.util.List;

public record RoleListDto(List<ActorRoleDto> roles) {
}
