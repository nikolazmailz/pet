package ru.ntdev.srhr.requisition.infra;

import ru.ntdev.srhr.requisition.domain.BscsEmployeeDto;

public interface BscsIntegrationService {
    BscsEmployeeDto getStaffByLogin(String adLogin, String sessionId, String traceId);
}
