package ru.ntdev.srhr.requisition.service;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import ru.ntdev.srhr.requestreply.model.RequestEnvelope;
import ru.ntdev.srhr.requisition.context.RequestContext;
import ru.ntdev.srhr.requisition.context.RequestContextHolder;
import ru.ntdev.srhr.requisition.domain.ActorRoleDto;
import ru.ntdev.srhr.requisition.domain.BscsEmployeeDto;
import ru.ntdev.srhr.requisition.domain.RequisitionRequestEntity;
import ru.ntdev.srhr.requisition.domain.RoleListDto;
import ru.ntdev.srhr.requisition.domain.SapSystemParamsDto;
import ru.ntdev.srhr.requisition.infra.BscsIntegrationService;
import ru.ntdev.srhr.requisition.infra.EntityService;
import ru.ntdev.srhr.requisition.infra.FilestorageService;
import ru.ntdev.srhr.requisition.infra.TsrmIntegrationService;

import java.util.Comparator;
import java.util.Map;

public class PreparedRequestService {
    private static final String SENT = "SENT";
    private static final Map<String, Integer> ROLE_PRIORITY = Map.of(
            "MSS_FULL", 400,
            "MSS_STANDARD", 300,
            "MSS_LIMITED", 200,
            "ESS", 100
    );

    private final ObjectMapper mapper;
    private final EntityService entityService;
    private final TsrmIntegrationService tsrmIntegrationService;
    private final BscsIntegrationService bscsIntegrationService;
    private final FilestorageService filestorageService;

    public PreparedRequestService(ObjectMapper mapper,
                                  EntityService entityService,
                                  TsrmIntegrationService tsrmIntegrationService,
                                  BscsIntegrationService bscsIntegrationService,
                                  FilestorageService filestorageService) {
        this.mapper = mapper;
        this.entityService = entityService;
        this.tsrmIntegrationService = tsrmIntegrationService;
        this.bscsIntegrationService = bscsIntegrationService;
        this.filestorageService = filestorageService;
    }

    public PreparedRequest<JsonNode> prepare(String originalMessage) throws Exception {
        long startedAt = System.currentTimeMillis();

        RequestEnvelope<JsonNode> envelope = deserialize(originalMessage);
        envelope = restoreFromFilestorageIfNeeded(envelope);

        SapSystemParamsDto systemParams = createSystemParams(envelope);
        setRequestContext(systemParams);
        logIncomingMessage(systemParams);

        RequisitionRequestEntity requestEntity = saveRequest(systemParams, originalMessage);
        enrichRoles(systemParams, requestEntity);
        enrichTabNumber(systemParams, requestEntity);

        return new PreparedRequest<>(envelope, systemParams, requestEntity, startedAt);
    }

    private RequestEnvelope<JsonNode> deserialize(String message) throws Exception {
        JavaType type = mapper.getTypeFactory()
                .constructParametricType(RequestEnvelope.class, JsonNode.class);
        return mapper.readValue(message, type);
    }

    private RequestEnvelope<JsonNode> restoreFromFilestorageIfNeeded(RequestEnvelope<JsonNode> envelope) throws Exception {
        if (envelope.fileUuid() == null || envelope.fileUuid().isBlank()) {
            return envelope;
        }

        String storedMessage = filestorageService.getMessageContent(
                envelope.adLogin(),
                envelope.sessionId(),
                envelope.traceId(),
                envelope.fileUuid()
        );

        return deserialize(storedMessage);
    }

    private SapSystemParamsDto createSystemParams(RequestEnvelope<?> request) {
        SapSystemParamsDto systemParams = new SapSystemParamsDto();
        systemParams.setRequestType(request.requestType());
        systemParams.setAdLogin(request.adLogin());
        systemParams.setChannel(request.channel());
        systemParams.setSessionId(request.sessionId());
        systemParams.setTraceId(request.traceId());
        systemParams.setUuid(request.correlationId());
        systemParams.setRealm(request.realm());
        return systemParams;
    }

    private void setRequestContext(SapSystemParamsDto systemParams) {
        RequestContextHolder.set(new RequestContext(
                systemParams.getAdLogin(),
                systemParams.getSessionId(),
                systemParams.getChannel()
        ));
    }

    private void logIncomingMessage(SapSystemParamsDto systemParams) {
        System.out.printf("Kafka message got: login=%s session=%s requestType=%s traceId=%s%n",
                systemParams.getAdLogin(),
                systemParams.getSessionId(),
                systemParams.getRequestType(),
                systemParams.getTraceId());
    }

    private RequisitionRequestEntity saveRequest(SapSystemParamsDto systemParams, String originalMessage) {
        return entityService.saveAndReturnRequest(
                systemParams.getUuid(),
                null,
                systemParams.getSessionId(),
                originalMessage,
                null,
                SENT
        );
    }

    private void enrichRoles(SapSystemParamsDto systemParams, RequisitionRequestEntity requestEntity) throws Exception {
        RoleListDto roles = tsrmIntegrationService.getRole(
                systemParams.getAdLogin(),
                systemParams.getChannel(),
                systemParams.getSessionId(),
                systemParams.getTraceId()
        );

        if (roles == null || roles.roles() == null || roles.roles().isEmpty()) {
            throw new IllegalStateException("Роль для пользователя " + systemParams.getAdLogin() + " не найдена");
        }

        String role = roles.roles().stream()
                .filter(it -> ROLE_PRIORITY.containsKey(it.roleId()))
                .max(Comparator.comparingInt(it -> ROLE_PRIORITY.get(it.roleId())))
                .map(ActorRoleDto::roleId)
                .orElseThrow(() -> new IllegalStateException("Поддерживаемая роль не найдена"));

        systemParams.setRolesHeader(mapper.writeValueAsString(roles));
        systemParams.setRole(role);
        requestEntity.setFunctionalRole(role);
        entityService.updateRequestRole(systemParams.getUuid(), role);
    }

    private void enrichTabNumber(SapSystemParamsDto systemParams, RequisitionRequestEntity requestEntity) {
        BscsEmployeeDto employee = bscsIntegrationService.getStaffByLogin(
                systemParams.getAdLogin(),
                systemParams.getSessionId(),
                systemParams.getTraceId()
        );

        if (employee == null || employee.id() == null) {
            throw new IllegalStateException("Табельный номер пользователя " + systemParams.getAdLogin() + " не найден");
        }

        systemParams.setTabNumber(employee.id());
        requestEntity.setTabNumber(employee.id());
        entityService.updateRequestTabnum(systemParams.getUuid(), employee.id());
    }
}
