package ru.ntdev.srhr.requisition.domain;

public class SapSystemParamsDto {
    private String requestType;
    private String adLogin;
    private String channel;
    private String sessionId;
    private String traceId;
    private String uuid;
    private String realm;
    private String role;
    private String rolesHeader;
    private String tabNumber;

    public String getRequestType() { return requestType; }
    public void setRequestType(String requestType) { this.requestType = requestType; }
    public String getAdLogin() { return adLogin; }
    public void setAdLogin(String adLogin) { this.adLogin = adLogin; }
    public String getChannel() { return channel; }
    public void setChannel(String channel) { this.channel = channel; }
    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
    public String getTraceId() { return traceId; }
    public void setTraceId(String traceId) { this.traceId = traceId; }
    public String getUuid() { return uuid; }
    public void setUuid(String uuid) { this.uuid = uuid; }
    public String getRealm() { return realm; }
    public void setRealm(String realm) { this.realm = realm; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getRolesHeader() { return rolesHeader; }
    public void setRolesHeader(String rolesHeader) { this.rolesHeader = rolesHeader; }
    public String getTabNumber() { return tabNumber; }
    public void setTabNumber(String tabNumber) { this.tabNumber = tabNumber; }
}
