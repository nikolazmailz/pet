package ru.ntdev.srhr.requisition.usecase;

import java.util.List;

public record PendingCandidatesRequest(
        int page,
        int pageSize,
        String fullName,
        List<String> eventCodes
) {
}
