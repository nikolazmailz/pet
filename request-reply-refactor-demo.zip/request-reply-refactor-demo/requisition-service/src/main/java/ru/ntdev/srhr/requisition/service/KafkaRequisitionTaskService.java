package ru.ntdev.srhr.requisition.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.ntdev.srhr.requestreply.model.ResponseEnvelope;

public class KafkaRequisitionTaskService {
    private final PreparedRequestService preparedRequestService;
    private final RequestHandlerExecutor requestHandlerExecutor;
    private final ObjectMapper objectMapper;

    public KafkaRequisitionTaskService(PreparedRequestService preparedRequestService,
                                       RequestHandlerExecutor requestHandlerExecutor,
                                       ObjectMapper objectMapper) {
        this.preparedRequestService = preparedRequestService;
        this.requestHandlerExecutor = requestHandlerExecutor;
        this.objectMapper = objectMapper;
    }

    public String processMessage(String messageIncoming) throws Exception {
        PreparedRequest<com.fasterxml.jackson.databind.JsonNode> prepared = preparedRequestService.prepare(messageIncoming);
        ResponseEnvelope<?> response = requestHandlerExecutor.execute(prepared);
        return objectMapper.writeValueAsString(response);
    }
}
