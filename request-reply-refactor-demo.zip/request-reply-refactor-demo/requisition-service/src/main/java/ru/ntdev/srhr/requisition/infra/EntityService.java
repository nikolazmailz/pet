package ru.ntdev.srhr.requisition.infra;

import ru.ntdev.srhr.requisition.domain.RequisitionRequestEntity;

public interface EntityService {
    RequisitionRequestEntity saveAndReturnRequest(String uid, String role, String sessionId, String body, String tabNumber, String status);
    void updateRequestRole(String uid, String role);
    void updateRequestTabnum(String uid, String tabNumber);
}
