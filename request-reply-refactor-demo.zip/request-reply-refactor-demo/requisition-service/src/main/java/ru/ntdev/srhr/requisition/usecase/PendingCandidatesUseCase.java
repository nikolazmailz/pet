package ru.ntdev.srhr.requisition.usecase;

import ru.ntdev.srhr.requisition.domain.SapSystemParamsDto;

public interface PendingCandidatesUseCase {
    PendingCandidatesResponse execute(SapSystemParamsDto systemParams, PendingCandidatesRequest request);
}
