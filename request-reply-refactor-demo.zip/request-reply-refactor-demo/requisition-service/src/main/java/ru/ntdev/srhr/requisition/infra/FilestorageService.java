package ru.ntdev.srhr.requisition.infra;

public interface FilestorageService {
    String getMessageContent(String adLogin, String sessionId, String traceId, String fileUuid);
}
