package ru.ntdev.srhr.requisition.infra;

import ru.ntdev.srhr.requisition.domain.RoleListDto;

public interface TsrmIntegrationService {
    RoleListDto getRole(String adLogin, String channel, String sessionId, String traceId);
}
