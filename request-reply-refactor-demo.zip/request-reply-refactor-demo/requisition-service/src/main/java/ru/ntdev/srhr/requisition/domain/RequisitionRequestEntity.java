package ru.ntdev.srhr.requisition.domain;

public class RequisitionRequestEntity {
    private String functionalRole;
    private String tabNumber;

    public String getFunctionalRole() { return functionalRole; }
    public void setFunctionalRole(String functionalRole) { this.functionalRole = functionalRole; }
    public String getTabNumber() { return tabNumber; }
    public void setTabNumber(String tabNumber) { this.tabNumber = tabNumber; }
}
