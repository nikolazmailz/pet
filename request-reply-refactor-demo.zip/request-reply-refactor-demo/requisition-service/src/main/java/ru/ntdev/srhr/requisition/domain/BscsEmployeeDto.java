package ru.ntdev.srhr.requisition.domain;

public record BscsEmployeeDto(String id) {
}
