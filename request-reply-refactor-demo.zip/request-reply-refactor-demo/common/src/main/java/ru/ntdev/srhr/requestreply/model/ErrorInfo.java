package ru.ntdev.srhr.requestreply.model;

public record ErrorInfo(String code, String message) {
}
