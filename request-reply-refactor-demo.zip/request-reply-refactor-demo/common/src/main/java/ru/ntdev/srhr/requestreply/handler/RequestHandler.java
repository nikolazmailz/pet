package ru.ntdev.srhr.requestreply.handler;

public interface RequestHandler<T, R, C> {
    String requestType();
    Class<T> requestClass();
    R handle(C context) throws Exception;
}
