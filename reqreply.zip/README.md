# reqreply: filestorage в common

## Структура

```
common/src/main/java/ru/ntdev/srhr/common/reqreply/
├── req/
│   ├── FilestorageService.java      — интерфейс (пока только putMessageToDb)
│   ├── FilestorageServiceImpl.java  — реализация поверх FilestorageRestClient
│   ├── FilestorageRestClient.java   — переписанный клиент: один RestTemplate,
│   │                                  заголовки per-request через HttpEntity
│   └── RequestSender.java           — обновлён: принимает FilestorageService,
│                                      исправлен баг setTraceId(getRequestType()),
│                                      убран локальный new ObjectMapper()
└── dto/
    ├── MessagePostRequestDto.java
    └── MessagePostDto.java

service-example/
└── ReqReplyConfig.java              — пример объявления бинов в сервисе
```

## Что сделать после распаковки

1. Скопировать содержимое `common/src/...` в модуль common (пакеты уже верные).
2. Убедиться, что старый FilestorageService/Impl/RestClient в сервисе либо удалён,
   либо не конфликтует по именам (следить за импортами).
3. IntegrationRequestInterceptor: если нужен — передать в конструктор
   FilestorageRestClient списком (см. комментарий в ReqReplyConfig).
4. Свойства в application.yml сервиса:
   - filestorage.rest.service.url
   - kafka.producer.max-inner-message-size-kb
