package ru.ntdev.srhr.common.reqreply.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MessagePostDto {
    private String messageUID;
}
