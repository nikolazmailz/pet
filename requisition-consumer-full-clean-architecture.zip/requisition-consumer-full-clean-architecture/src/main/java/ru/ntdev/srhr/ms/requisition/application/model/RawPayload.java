package ru.ntdev.srhr.ms.requisition.application.model;
public record RawPayload(String json) {}
