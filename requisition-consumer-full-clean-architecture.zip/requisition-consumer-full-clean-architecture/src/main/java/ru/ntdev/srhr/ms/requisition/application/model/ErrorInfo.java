package ru.ntdev.srhr.ms.requisition.application.model;
public record ErrorInfo(String code, String message) {}
