package ru.ntdev.srhr.ms.requisition.application.model;
public record ResponseRecord(Long id,String correlationId,String responseBody,long processingTime,String code) {}
