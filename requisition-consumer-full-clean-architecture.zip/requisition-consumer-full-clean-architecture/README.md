# Полная связка второго сервиса

Основано на старом `KafkaRequisitionTaskService.processMessage()`.

## Поток

```text
Kafka listener
  -> MessageProcessingService.processMessage
  -> deserialize RequestEnvelope<RawPayload>
  -> PreparedRequestService
       -> restoreFromFilestorageIfNeeded
       -> createSystemParams
       -> RequestContext
       -> incoming log
       -> saveRequest
       -> roles + highest priority role
       -> updateRequestRole
       -> tabNumber
       -> updateRequestTabNumber
  -> RequestHandlerResolver
  -> RequestHandlerExecutor
       -> RawPayload -> concrete Request DTO
  -> concrete Handler
  -> UseCase
  -> ResponseProcessingService
       -> update status REPLY / ERROR_REPLY
       -> fill common response metadata
       -> serialize full response
       -> saveResponse (аналог saveAndGetResponse)
       -> calculate processingTime
       -> success cleanup request/response
       -> checkMessageSize
       -> large response -> filestorage + fileUuid
  -> Kafka response producer
```

## Что здесь НЕ потеряно из старой общей части

- восстановление входящего сообщения по `fileUuid`;
- создание system params;
- RequestContext;
- логирование входящего Kafka message;
- `saveAndGetEntity` / сохранение request;
- получение roles;
- выбор highest priority role;
- сохранение role в request;
- получение tabNumber;
- сохранение tabNumber;
- обработка ошибок подготовки;
- `saveAndGetResponse`;
- processingTime;
- update status `REPLY` / `ERROR_REPLY`;
- удаление request/response при `200`;
- `checkMessageSize` ответа;
- сохранение большого ответа в filestorage;
- возврат компактного ответа с `fileUuid`;
- пустой request body через `RequestHandler<Void, R>`.

## Что остается внутри конкретных UseCase

Все, что раньше было внутри отдельных `case` после `switch`:
валидации вакансий/делегаций, кеши, вызовы database/candidate/interviewer service и т.д.

## Как заменить demo adapters реальными SRHR сервисами

- `DemoFileStorageAdapter` -> `FilestorageService`
- `DemoRoleAdapter` -> `TsrmIntegrationService`
- `DemoStaffAdapter` -> `BscsIntegrationService`
- `InMemoryRequestPersistenceAdapter` -> `EntityServiceImpl`

В комментариях адаптеров указаны старые методы, которым они соответствуют.

## Важное архитектурное разделение

`PreparedRequestService` = общая логика ДО UseCase.

`RequestHandler` = замена `switch(requestType)`.

`UseCase` = бизнес-логика операции.

`ResponseProcessingService` = общая логика ПОСЛЕ UseCase.
