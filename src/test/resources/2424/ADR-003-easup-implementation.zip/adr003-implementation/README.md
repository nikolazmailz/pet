# ADR-003 — исходники для переноса `GET /event`

Реализация соответствует **ADR-003**: нет `RequestContext`, `RequestContextInterceptor` и дополнительных resolver для контекста; `@SapSystemParams` остаётся, аудит инициируется из нового `ControllerAdvice` и маршрутизируется через `supports(requestType)`.

## Состав

- `annotation/RequestType.java` — идентификатор операции на методе.
- `annotation/MigratedEasupEndpoint.java` — маркер новых контроллеров; изоляция нового `ControllerAdvice`.
- `controller/PayavgController.java` — REST-эндпоинт.
- `service/PayavgService.java` — правило `null → 404`.
- `port/PayavgIntegrationPort.java` — контракт к целевому EASUP-клиенту, адаптер написать под реальный API отдельно.
- `port/IntegrationErrorMapper.java` — готовый преобразователь ошибок для RestTemplate-подобного клиента, опционально.
- `exception/*` — типизированные исключения.
- `audit/*` — стратегии, resolver, dispatcher и параметры аудита.
- `handler/IntegrationExceptionHandler.java` — HTTP-ответы и вызов аудита.
- `src/test` — unit-тесты resolver и сервиса.

## Что потребуется связать с целевым проектом

1. **Исправить два импорта**: `PayavgEventDto` (в 3 исходниках) и существующей аннотации `@SapSystemParams` (в контроллере). Пакеты этих классов не были предоставлены, поэтому они отмечены `TODO`.
2. В `PayavgController` сохранить исходный class-level `@RequestMapping`, если был в старом контроллере, чтобы не изменить полный URL.
3. Реализовать `PayavgIntegrationPort` с использованием **уже существующего EASUP-клиента целевого сервиса**. Это вне задачи. Преобразование `HttpStatusCodeException` и `ResourceAccessException` удобно выполнить на границе этого адаптера.
4. Проверить доступность `AuditEventSenderCustom` и его трёх методов в целевом сервисе. Если его там нет, заменить делегирование тремя существующими вызовами TSAU из целевого сервиса.
5. Убедиться, что существующий `HandlerMethodArgumentResolver` действительно поддерживает `@SapSystemParams` и зарегистрирован.
6. Согласовать HTTP-статусы и структуру SAP `ServiceErrorDto` — текущий пример **сохраняет внешние статусы 401/403/404/5xx**, возвращает типизированный ServiceErrorDto и не копирует SAP details. Для полной контрактной эквивалентности потребуется дополнительная обработка структуры SAP-ошибки.
7. Добавить интеграционные `MockMvc`-тесты в целевом сервисе (с реальным resolver, security, конфигурацией контроллеров). Эти проверки требуют конкретной конфигурации проекта и не могут быть универсальными.

## Важные ограничения

- Старый `@ControllerAdvice` остаётся глобальным. Новый `@RestControllerAdvice(annotations=MigratedEasupEndpoint.class)` с `@Order(HIGHEST_PRECEDENCE)` обрабатывает помеченные контроллеры. Это необходимо проверить через `MockMvc`.
- `HandlerMapping.BEST_MATCHING_HANDLER_ATTRIBUTE` присутствует только после сопоставления метода в Spring MVC. При ранней ошибке Spring Security метаданные операции не определяются; соответствующий аудит настраивается отдельно.
- Если два sender возвращают true, resolver выбрасывает ошибку конфигурации; dispatcher её логирует, сохраняя исходный HTTP-ответ.
- Отправка аудита может упасть: dispatcher логирует сбой и не подменяет первоначальную ошибку.
- `HttpServletRequest` используется для чтения заголовков **только внутри нового обработчика аудита/ошибок**, без ручного `setAttributes()` в контроллере. Для персональных заголовков требуется доверенный upstream либо security context.
- Для HTTP 510 сохранение/исключение аудита зависит от того, как старый клиент классифицировал ответ. В примере 510 не аудируется; это нужно проверить по старым тестам.

## Maven зависимости (обычно уже есть в целевом сервисе)

`spring-boot-starter-web`, `lombok`, `spring-boot-starter-test` (scope test), существующий `mod-commons` с `ServiceErrorDto` / `SapSystemParamsDto`, реализация `AuditEventSenderCustom`.

Код предназначен для **встраивания в целевой сервис**, не является отдельным запускаемым Spring Boot приложением.
