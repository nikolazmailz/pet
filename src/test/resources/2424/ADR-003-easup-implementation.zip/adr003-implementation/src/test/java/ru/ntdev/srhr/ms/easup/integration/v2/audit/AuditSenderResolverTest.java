package ru.ntdev.srhr.ms.easup.integration.v2.audit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import org.junit.jupiter.api.Test;

class AuditSenderResolverTest {
    @Test
    void resolvesOneMatchingSender() {
        AuditSender one = mock(AuditSender.class);
        AuditSender two = mock(AuditSender.class);
        when(one.supports("easup_payavg_event")).thenReturn(false);
        when(two.supports("easup_payavg_event")).thenReturn(true);

        assertSame(two, new AuditSenderResolver(List.of(one, two))
                .resolve("easup_payavg_event").orElseThrow());
    }

    @Test
    void returnsEmptyForUnknownOperation() {
        AuditSender sender = mock(AuditSender.class);
        assertTrue(new AuditSenderResolver(List.of(sender))
                .resolve("unknown").isEmpty());
    }

    @Test
    void returnsEmptyForNullOperation() {
        assertTrue(new AuditSenderResolver(List.of()).resolve(null).isEmpty());
    }

    @Test
    void rejectsAmbiguousSenders() {
        AuditSender one = mock(AuditSender.class);
        AuditSender two = mock(AuditSender.class);
        when(one.supports("operation")).thenReturn(true);
        when(two.supports("operation")).thenReturn(true);

        assertThrows(IllegalStateException.class,
                () -> new AuditSenderResolver(List.of(one, two))
                        .resolve("operation"));
    }
}
