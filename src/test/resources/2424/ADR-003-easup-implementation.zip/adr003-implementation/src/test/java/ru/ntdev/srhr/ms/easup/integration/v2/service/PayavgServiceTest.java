package ru.ntdev.srhr.ms.easup.integration.v2.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import ru.ntdev.srhr.common.dto.SapSystemParamsDto;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.PayavgEventNotFoundException;
import ru.ntdev.srhr.ms.easup.integration.v2.port.PayavgIntegrationPort;

class PayavgServiceTest {
    @Test
    void nullResponseBecomesNotFound() {
        PayavgIntegrationPort port = mock(PayavgIntegrationPort.class);
        SapSystemParamsDto params = new SapSystemParamsDto();
        when(port.getPayavgEvent(params)).thenReturn(null);
        PayavgService service = new PayavgService(port);
        assertThrows(PayavgEventNotFoundException.class,
                () -> service.getPayavgEvent(params));
    }
}
