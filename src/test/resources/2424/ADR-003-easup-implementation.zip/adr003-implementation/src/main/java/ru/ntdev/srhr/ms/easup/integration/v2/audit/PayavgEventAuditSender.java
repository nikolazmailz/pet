package ru.ntdev.srhr.ms.easup.integration.v2.audit;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.ntdev.srhr.ms.easup.integration.audit.service.AuditEventSenderCustom;

@Component
@RequiredArgsConstructor
public class PayavgEventAuditSender implements AuditSender {
    private static final String REQUEST_TYPE = "easup_payavg_event";
    private final AuditEventSenderCustom delegate;

    @Override
    public boolean supports(String requestType) {
        return REQUEST_TYPE.equals(requestType);
    }

    @Override
    public void sendUnexpectedError(AuditEventData data) throws Exception {
        delegate.sendEasupPayavgEventError(
                data.occurredAt(), data.pernr(), data.sessionId(), data.adLogin());
    }

    @Override
    public void sendForbidden(AuditEventData data) throws Exception {
        delegate.sendEasupPayavgEventForbidden(
                data.occurredAt(), data.pernr(), data.sessionId(), data.adLogin());
    }

    @Override
    public void sendNotFound(AuditEventData data) throws Exception {
        delegate.sendEasupPayavgEventNotFound(
                data.occurredAt(), data.pernr(), data.sessionId(), data.adLogin());
    }
}
