package ru.ntdev.srhr.ms.easup.integration.v2.port;

import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.ExternalSystemException;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.ExternalSystemUnavailableException;

/** Использовать внутри адаптера целевого HTTP-клиента, не в контроллере. */
public final class IntegrationErrorMapper {
    private IntegrationErrorMapper() {}

    public static RuntimeException map(RuntimeException error) {
        if (error instanceof HttpStatusCodeException ex) {
            return new ExternalSystemException(
                    ex.getStatusCode().value(), "Ошибка ответа EASUP", ex);
        }
        if (error instanceof ResourceAccessException ex) {
            return new ExternalSystemUnavailableException(ex);
        }
        return error;
    }
}
