package ru.ntdev.srhr.ms.easup.integration.v2.audit;

public enum AuditErrorType {
    UNEXPECTED,
    FORBIDDEN,
    NOT_FOUND
}
