package ru.ntdev.srhr.ms.easup.integration.v2.exception;

public class ExternalSystemUnavailableException extends RuntimeException {
    public ExternalSystemUnavailableException(Throwable cause) {
        super("Интеграционная система EASUP недоступна", cause);
    }
}
