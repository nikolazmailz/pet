package ru.ntdev.srhr.ms.easup.integration.v2.audit;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuditSenderResolver {
    private final List<AuditSender> senders;

    public Optional<AuditSender> resolve(String requestType) {
        if (requestType == null || requestType.isBlank()) {
            return Optional.empty();
        }
        List<AuditSender> matches = senders.stream()
                .filter(sender -> sender.supports(requestType))
                .toList();
        if (matches.size() > 1) {
            throw new IllegalStateException(
                    "Multiple audit senders support requestType=" + requestType);
        }
        return matches.stream().findFirst();
    }
}
