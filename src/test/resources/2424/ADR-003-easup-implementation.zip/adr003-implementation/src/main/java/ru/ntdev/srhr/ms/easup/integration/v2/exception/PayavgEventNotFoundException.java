package ru.ntdev.srhr.ms.easup.integration.v2.exception;

public class PayavgEventNotFoundException extends RuntimeException {
    public PayavgEventNotFoundException() {
        // При переносе можно заменить на ErrorResponse.EASUP_REQUEST_NOT_FOUND.
        super("Данные события среднего заработка не найдены");
    }
}
