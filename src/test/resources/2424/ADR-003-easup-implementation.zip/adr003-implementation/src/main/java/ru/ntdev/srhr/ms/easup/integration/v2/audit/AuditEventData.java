package ru.ntdev.srhr.ms.easup.integration.v2.audit;

import java.time.LocalDateTime;

/** Данные одного события аудита, не общий RequestContext. */
public record AuditEventData(
        LocalDateTime occurredAt,
        String pernr,
        String sessionId,
        String adLogin
) {}
