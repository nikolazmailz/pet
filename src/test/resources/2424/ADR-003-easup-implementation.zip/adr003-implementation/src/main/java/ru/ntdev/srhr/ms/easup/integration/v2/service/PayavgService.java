package ru.ntdev.srhr.ms.easup.integration.v2.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.ntdev.srhr.common.dto.SapSystemParamsDto;
// TODO: заменить на фактический импорт PayavgEventDto в целевом сервисе.
import ru.ntdev.srhr.ms.easup.integration.dto.PayavgEventDto;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.PayavgEventNotFoundException;
import ru.ntdev.srhr.ms.easup.integration.v2.port.PayavgIntegrationPort;

@Service
@RequiredArgsConstructor
public class PayavgService {
    private final PayavgIntegrationPort integrationPort;

    public PayavgEventDto getPayavgEvent(SapSystemParamsDto systemParams) {
        PayavgEventDto result = integrationPort.getPayavgEvent(systemParams);
        if (result == null) {
            throw new PayavgEventNotFoundException();
        }
        return result;
    }
}
