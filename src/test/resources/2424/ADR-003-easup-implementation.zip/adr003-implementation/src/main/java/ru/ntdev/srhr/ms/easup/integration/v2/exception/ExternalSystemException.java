package ru.ntdev.srhr.ms.easup.integration.v2.exception;

public class ExternalSystemException extends RuntimeException {
    private final int upstreamStatus;

    public ExternalSystemException(int upstreamStatus, String message, Throwable cause) {
        super(message, cause);
        this.upstreamStatus = upstreamStatus;
    }

    public int getUpstreamStatus() {
        return upstreamStatus;
    }
}
