package ru.ntdev.srhr.ms.easup.integration.v2.handler;

import jakarta.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import ru.ntdev.srhr.common.dto.api.error.ServiceError;
import ru.ntdev.srhr.common.dto.api.error.ServiceErrorDto;
import ru.ntdev.srhr.ms.easup.integration.v2.annotation.MigratedEasupEndpoint;
import ru.ntdev.srhr.ms.easup.integration.v2.audit.AuditErrorType;
import ru.ntdev.srhr.ms.easup.integration.v2.audit.AuditSenderDispatcher;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.ExternalSystemException;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.ExternalSystemUnavailableException;
import ru.ntdev.srhr.ms.easup.integration.v2.exception.PayavgEventNotFoundException;

@Slf4j
@RestControllerAdvice(annotations = MigratedEasupEndpoint.class)
@Order(Ordered.HIGHEST_PRECEDENCE)
@RequiredArgsConstructor
public class IntegrationExceptionHandler {
    private final AuditSenderDispatcher auditDispatcher;

    @ExceptionHandler(PayavgEventNotFoundException.class)
    public ResponseEntity<ServiceErrorDto> notFound(
            PayavgEventNotFoundException ex, HttpServletRequest request) {
        auditDispatcher.sendSafely(request, AuditErrorType.NOT_FOUND);
        return build(HttpStatus.NOT_FOUND.value(), ex.getMessage(), request);
    }

    @ExceptionHandler(ExternalSystemException.class)
    public ResponseEntity<ServiceErrorDto> upstreamError(
            ExternalSystemException ex, HttpServletRequest request) {
        int upstreamStatus = ex.getUpstreamStatus();
        // До согласования контракта сохраняем внешний HTTP-статус как в исходном handler.
        // В исходном handler HTTP 510 исключался из аудита в ветке HttpServerErrorException.
        if (upstreamStatus != 510) {
            AuditErrorType type = upstreamStatus == 401 || upstreamStatus == 403
                    ? AuditErrorType.FORBIDDEN
                    : upstreamStatus == 404
                        ? AuditErrorType.NOT_FOUND
                        : AuditErrorType.UNEXPECTED;
            auditDispatcher.sendSafely(request, type);
        }
        log.warn("EASUP returned HTTP {}", upstreamStatus, ex);
        // HttpStatusCode.valueOf допускает нестандартные 5xx, включая 510.
        return ResponseEntity.status(upstreamStatus)
                .body(error("Ошибка обращения к EASUP", String.valueOf(upstreamStatus), request));
    }

    @ExceptionHandler(ExternalSystemUnavailableException.class)
    public ResponseEntity<ServiceErrorDto> unavailable(
            ExternalSystemUnavailableException ex, HttpServletRequest request) {
        auditDispatcher.sendSafely(request, AuditErrorType.UNEXPECTED);
        log.error("EASUP unavailable", ex);
        return build(HttpStatus.SERVICE_UNAVAILABLE.value(),
                "Внешняя система недоступна", request);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ServiceErrorDto> unexpected(
            Exception ex, HttpServletRequest request) {
        auditDispatcher.sendSafely(request, AuditErrorType.UNEXPECTED);
        log.error("Unhandled error during EASUP operation", ex);
        return build(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Внутренняя ошибка сервиса", request);
    }

    private ResponseEntity<ServiceErrorDto> build(
            int status, String message, HttpServletRequest request) {
        return ResponseEntity.status(status)
                .body(error(message, String.valueOf(status), request));
    }

    private ServiceErrorDto error(
            String message, String code, HttpServletRequest request) {
        String traceId = request.getHeader("logId");
        if (traceId == null || traceId.isBlank()) {
            traceId = "undefined";
        }
        return new ServiceErrorDto(new ServiceError(
                message, code, traceId, new ArrayList<>()));
    }
}
