package ru.ntdev.srhr.ms.easup.integration.v2.audit;

public interface AuditSender {
    boolean supports(String requestType);
    void sendUnexpectedError(AuditEventData data) throws Exception;
    void sendForbidden(AuditEventData data) throws Exception;
    void sendNotFound(AuditEventData data) throws Exception;
}
