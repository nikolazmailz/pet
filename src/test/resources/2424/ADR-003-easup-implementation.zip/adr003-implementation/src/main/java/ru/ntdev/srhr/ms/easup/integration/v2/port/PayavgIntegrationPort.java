package ru.ntdev.srhr.ms.easup.integration.v2.port;

import ru.ntdev.srhr.common.dto.SapSystemParamsDto;
// TODO: заменить на фактический импорт PayavgEventDto в целевом сервисе.
import ru.ntdev.srhr.ms.easup.integration.dto.PayavgEventDto;

/** Порт для существующего клиента целевого сервиса; реализация отдельно. */
public interface PayavgIntegrationPort {
    PayavgEventDto getPayavgEvent(SapSystemParamsDto params);
}
