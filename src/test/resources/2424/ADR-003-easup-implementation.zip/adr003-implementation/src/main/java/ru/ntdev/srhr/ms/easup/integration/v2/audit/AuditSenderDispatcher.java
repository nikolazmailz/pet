package ru.ntdev.srhr.ms.easup.integration.v2.audit;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerMapping;
import ru.ntdev.srhr.ms.easup.integration.v2.annotation.RequestType;

@Slf4j
@Component
@RequiredArgsConstructor
public class AuditSenderDispatcher {
    private final AuditSenderResolver resolver;

    public void sendSafely(HttpServletRequest request, AuditErrorType type) {
        try {
            Optional<String> requestType = resolveRequestType(request);
            if (requestType.isEmpty()) {
                log.warn("Audit skipped: mapped @RequestType not available");
                return;
            }
            Optional<AuditSender> sender = resolver.resolve(requestType.get());
            if (sender.isEmpty()) {
                log.warn("Audit skipped: no AuditSender for {}", requestType.get());
                return;
            }
            AuditEventData data = new AuditEventData(
                    LocalDateTime.now(),
                    request.getHeader("pernr"),
                    request.getHeader("sessionId"),
                    request.getHeader("X-user-login")
            );
            switch (type) {
                case UNEXPECTED -> sender.get().sendUnexpectedError(data);
                case FORBIDDEN -> sender.get().sendForbidden(data);
                case NOT_FOUND -> sender.get().sendNotFound(data);
            }
        } catch (Exception ex) {
            // Сбой аудита не должен заменять исходную ошибку API.
            log.error("Failed to dispatch audit event", ex);
        }
    }

    public Optional<String> resolveRequestType(HttpServletRequest request) {
        Object matched = request.getAttribute(HandlerMapping.BEST_MATCHING_HANDLER_ATTRIBUTE);
        if (!(matched instanceof HandlerMethod method)) {
            return Optional.empty();
        }
        RequestType type = method.getMethodAnnotation(RequestType.class);
        return type == null ? Optional.empty() : Optional.of(type.value());
    }
}
