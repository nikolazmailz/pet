package ru.ntdev.srhr.ms.easup.integration.v2.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.ntdev.srhr.common.dto.SapSystemParamsDto;
// TODO: импортируйте существующую @SapSystemParams из целевого сервиса.
// import ...SapSystemParams;
// TODO: заменить на фактический импорт PayavgEventDto в целевом сервисе.
import ru.ntdev.srhr.ms.easup.integration.dto.PayavgEventDto;
import ru.ntdev.srhr.ms.easup.integration.v2.annotation.MigratedEasupEndpoint;
import ru.ntdev.srhr.ms.easup.integration.v2.annotation.RequestType;
import ru.ntdev.srhr.ms.easup.integration.v2.service.PayavgService;

@RestController
@MigratedEasupEndpoint
@RequiredArgsConstructor
public class PayavgController {
    private final PayavgService payavgService;

    // TODO: сохранить исходный class-level @RequestMapping, если он был в старом контроллере.
    @RequestType("easup_payavg_event")
    @GetMapping(value = "/event", produces = MediaType.APPLICATION_JSON_VALUE)
    public PayavgEventDto getPayavgEvent(@SapSystemParams SapSystemParamsDto params) {
        return payavgService.getPayavgEvent(params);
    }
}
