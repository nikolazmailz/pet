# SRHR: Export All (ZIP) and response files

- Stubs page > Export > **Export All (ZIP)** exports all current runtime mappings and every unique `response.bodyFileName` referenced by them.
- Inline `body` and `jsonBody` stay in the mapping JSON.
- Files are retrieved through `GET /__admin/files/{path}` and included as raw bytes inside `__files/`.
- Stub Editor > **Response body source** supports inline or a relative `__files/` path with optional upload. Upload uses `PUT /__admin/files/{path}` before creating/updating the mapping.
- The export intentionally fails if any referenced response file is missing; it never delivers a silently incomplete archive.
- **Limitations:** this exports only referenced response files (not orphan files); ZIP is an uncompressed archive; import ZIP is not implemented; uploading a file before a failed mapping save may leave an orphan file; a file path shared by multiple mappings is overwritten on upload. Use one WireMock instance. Protect `__admin` behind authentication and network restrictions.
- Build frontend locally: `cd webapp && npm ci && npm run build`. Then build Maven JAR after disabling the existing frontend plugin executions as discussed. The generated `webapp/dist` is packaged in `wiremock-gui/` inside the JAR.
- Smoke test: create inline mapping, create file-backed mapping with upload, request both endpoints, export ZIP, check paths and content, delete referenced file and check that export fails.
