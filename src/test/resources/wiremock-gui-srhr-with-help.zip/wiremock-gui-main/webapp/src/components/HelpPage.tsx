import { useState } from 'react';

type Article = { title: string; description: string; code?: string; note?: string };
type Section = { title: string; articles: Article[] };

const sections: Section[] = [
  {
    title: 'Общие сведения',
    articles: [
      {
        title: 'Назначение',
        description: 'srhr-ms-mock-service эмулирует внешние REST-интеграции SRHR-сервисов на DEV-стенде. Заглушки создаются и применяются через WireMock GUI, а затем экспортируются в репозиторий разработчиками.',
        note: 'Изменения в runtime могут исчезнуть при пересоздании Pod. После настройки стабов выгружайте ZIP и переносите его в Git.',
      },
      {
        title: 'Структура файлов',
        description: 'mappings/ содержит правила сопоставления HTTP-запросов. __files/ содержит отдельные тела ответов. Путь bodyFileName всегда задаётся относительно __files/.',
        code: 'srhr-ms-mock-service/\n├── mappings/\n│   ├── tsrm/\n│   ├── easup/\n│   └── filestorage/\n├── __files/\n│   ├── tsrm/\n│   ├── easup/\n│   └── filestorage/\n├── Dockerfile\n└── docker-compose.yml',
      },
    ],
  },
  {
    title: 'Ответы и файлы',
    articles: [
      {
        title: 'JSON внутри mapping',
        description: 'Для небольшого JSON-ответа используйте jsonBody. Отдельный файл не требуется.',
        code: JSON.stringify({ request: { method: 'GET', urlPath: '/users/123' }, response: { status: 200, jsonBody: { id: 123 } } }, null, 2),
      },
      {
        title: 'Ответ из __files/',
        description: 'Для больших или повторно используемых ответов выберите файл. Пример: __files/tsrm/get-role-response.json. В mapping указывается только путь относительно __files/.',
        code: JSON.stringify({ request: { method: 'GET', urlPathPattern: '/functional-role/[^/]+/[^/]+' }, response: { status: 200, headers: { 'Content-Type': 'application/json' }, bodyFileName: 'tsrm/get-role-response.json' } }, null, 2),
        note: 'При экспорте ZIP проверяйте наличие связанных файлов ответов в папке __files/.',
      },
    ],
  },
  {
    title: 'Request Matching',
    articles: [
      {
        title: 'Точный URL',
        description: 'urlPath сравнивает только путь, без query-параметров.',
        code: JSON.stringify({ request: { method: 'GET', urlPath: '/users/123' }, response: { status: 200 } }, null, 2),
      },
      {
        title: 'Регулярное выражение для URL',
        description: 'urlPathPattern позволяет выбирать запросы по шаблону, например для числового идентификатора.',
        code: JSON.stringify({ request: { method: 'GET', urlPathPattern: '/users/[0-9]+' }, response: { status: 200 } }, null, 2),
      },
      {
        title: 'Query-параметры',
        description: 'Например, GET /employees?department=IT&active=true.',
        code: JSON.stringify({ request: { method: 'GET', urlPath: '/employees', queryParameters: { department: { equalTo: 'IT' }, active: { equalTo: 'true' } } }, response: { status: 200 } }, null, 2),
      },
      {
        title: 'HTTP-заголовки',
        description: 'Значения можно проверять точно через equalTo или по регулярному выражению через matches.',
        code: JSON.stringify({ request: { method: 'GET', urlPath: '/profile', headers: { 'X-User-Login': { equalTo: 'test-user' }, 'X-Channel': { matches: 'WEB|MOBILE' } } }, response: { status: 200 } }, null, 2),
      },
      {
        title: 'Поле в JSON-запросе',
        description: 'matchesJsonPath позволяет проверить значение конкретного поля в JSON тела запроса.',
        code: JSON.stringify({ request: { method: 'POST', urlPath: '/search', bodyPatterns: [{ matchesJsonPath: "$[?(@.employeeId == '123')]" }] }, response: { status: 200 } }, null, 2),
      },
      {
        title: 'Сравнение JSON целиком',
        description: 'equalToJson сравнивает JSON, ignoreArrayOrder разрешает другой порядок элементов в массивах, ignoreExtraElements допускает дополнительные поля.',
        code: JSON.stringify({ request: { method: 'POST', urlPath: '/search', bodyPatterns: [{ equalToJson: { employeeId: '123', active: true }, ignoreArrayOrder: true, ignoreExtraElements: true }] }, response: { status: 200 } }, null, 2),
      },
    ],
  },
  {
    title: 'Ошибки и задержки',
    articles: [
      {
        title: 'Ответ с ошибкой',
        description: 'Можно эмулировать ошибку интеграции, например HTTP 500.',
        code: JSON.stringify({ request: { method: 'GET', urlPath: '/external/service' }, response: { status: 500, headers: { 'Content-Type': 'application/json' }, jsonBody: { code: '500', message: 'Mock external service error' } } }, null, 2),
      },
      {
        title: 'Задержка ответа',
        description: 'fixedDelayMilliseconds добавляет фиксированную задержку ответа в миллисекундах.',
        code: JSON.stringify({ response: { status: 200, fixedDelayMilliseconds: 5000 } }, null, 2),
      },
    ],
  },
  {
    title: 'Диагностика и публикация',
    articles: [
      {
        title: 'WireMock Admin API',
        description: 'Команды для локального запуска с портом 8089. На DEV URL и доступ к Admin API могут отличаться.',
        code: 'curl http://localhost:8089/__admin/mappings\ncurl http://localhost:8089/__admin/requests\ncurl -X DELETE http://localhost:8089/__admin/requests',
        note: 'Сброс журнала запросов удаляет диагностические данные. Admin API должен быть защищён от неавторизованного доступа.',
      },
      {
        title: 'Экспорт в репозиторий',
        description: 'Создайте или измените стаб, проверьте его работу и выполните Export All (ZIP). Разработчик переносит mappings/ и __files/ в Git, проверяет добавленные, изменённые и удалённые стабы, создаёт Merge Request. После CI/CD новая версия станет частью Docker-образа.',
        note: 'Экспортируйте изменения до пересоздания Pod — runtime-хранилище без PVC/PostgreSQL не обеспечивает сохранность изменений.',
      },
      {
        title: 'DEV-конфигурация',
        description: 'SRHR-сервисы могут направлять внешние интеграционные запросы в srhr-ms-mock-service вместо реальных систем.',
        code: 'TSRM_INTEGRATION_SERVICE_URL: http://srhr-ms-mock-service:8080\nEASUP_INTEGRATION_SERVICE_URL: http://srhr-ms-mock-service:8080',
      },
    ],
  },
];

function CodeExample({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };
  return (
    <div className="relative mt-3 rounded-lg border border-gray-200 bg-gray-900 text-gray-100">
      <button type="button" onClick={copy} className="absolute right-2 top-2 rounded bg-gray-700 px-2 py-1 text-xs hover:bg-gray-600">{copied ? 'Скопировано' : 'Копировать'}</button>
      <pre className="overflow-auto p-4 pr-24 text-xs leading-relaxed"><code>{code}</code></pre>
    </div>
  );
}

export function HelpPage() {
  const [query, setQuery] = useState('');
  const filtered = sections.map((section) => ({ ...section, articles: section.articles.filter((article) => `${section.title} ${article.title} ${article.description}`.toLowerCase().includes(query.toLowerCase())) })).filter((section) => section.articles.length > 0);
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Справка по SRHR WireMock</h1>
          <p className="mt-1 text-sm text-gray-600">Примеры создания заглушек, matching, файлов ответов и экспорта в Git.</p>
        </div>
        <input className="input w-full sm:w-72" placeholder="Поиск по справке..." value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Поиск по справке" />
      </div>
      {filtered.length === 0 && <p className="rounded-lg bg-white p-5 text-gray-500">По запросу ничего не найдено.</p>}
      {filtered.map((section) => (
        <section key={section.title} className="space-y-3">
          <h2 className="text-lg font-semibold text-gray-800">{section.title}</h2>
          {section.articles.map((article) => (
            <article key={article.title} className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
              <h3 className="font-semibold text-gray-900">{article.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-gray-600">{article.description}</p>
              {article.code && <CodeExample code={article.code} />}
              {article.note && <p className="mt-3 rounded-lg bg-amber-50 p-3 text-sm text-amber-900">{article.note}</p>}
            </article>
          ))}
        </section>
      ))}
    </div>
  );
}
