import type {
  StubMapping,
  StubMappingsResponse,
  RequestJournalResponse,
  ScenariosResponse,
  RecordingStatus,
  HealthResponse,
  VersionResponse,
  NearMissesResponse,
} from '../types/wiremock';

export class WireMockClient {
  private authToken: string | null = null;

  constructor(private baseUrl: string) {}

  setAuthToken(token: string | null) {
    this.authToken = token;
  }

  private async request<T>(path: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };
    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }
    const res = await fetch(url, { ...options, headers });
    if (res.status === 401) {
      window.dispatchEvent(new CustomEvent('wiremock-auth-expired'));
      throw new Error('Authentication required');
    }
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`${res.status} ${res.statusText}: ${text}`);
    }
    const text = await res.text();
    return text ? JSON.parse(text) : ({} as T);
  }

  // Stub Mappings
  async getAllStubMappings(limit?: number, offset?: number): Promise<StubMappingsResponse> {
    const params = new URLSearchParams();
    if (limit !== undefined) params.set('limit', String(limit));
    if (offset !== undefined) params.set('offset', String(offset));
    const qs = params.toString();
    return this.request(`/__admin/mappings${qs ? '?' + qs : ''}`);
  }

  async getStubMapping(id: string): Promise<StubMapping> {
    return this.request(`/__admin/mappings/${id}`);
  }

  async createStubMapping(mapping: StubMapping): Promise<StubMapping> {
    return this.request('/__admin/mappings', {
      method: 'POST',
      body: JSON.stringify(mapping),
    });
  }

  async updateStubMapping(id: string, mapping: StubMapping): Promise<StubMapping> {
    return this.request(`/__admin/mappings/${id}`, {
      method: 'PUT',
      body: JSON.stringify(mapping),
    });
  }

  async deleteStubMapping(id: string): Promise<void> {
    await this.request(`/__admin/mappings/${id}`, { method: 'DELETE' });
  }

  async deleteAllStubMappings(): Promise<void> {
    await this.request('/__admin/mappings', { method: 'DELETE' });
  }

  async resetStubMappings(): Promise<void> {
    await this.request('/__admin/mappings/reset', { method: 'POST' });
  }

  async persistStubMappings(): Promise<void> {
    await this.request('/__admin/mappings/save', { method: 'POST' });
  }

  async importStubMappings(mappings: StubMappingsResponse): Promise<void> {
    await this.request('/__admin/mappings/import', {
      method: 'POST',
      body: JSON.stringify(mappings),
    });
  }

  async getUnmatchedStubMappings(): Promise<StubMappingsResponse> {
    return this.request('/__admin/mappings/unmatched');
  }

  async removeUnmatchedStubMappings(): Promise<void> {
    await this.request('/__admin/mappings/unmatched', { method: 'DELETE' });
  }

  // Request Journal
  async getAllRequests(limit?: number, since?: string): Promise<RequestJournalResponse> {
    const params = new URLSearchParams();
    if (limit !== undefined) params.set('limit', String(limit));
    if (since) params.set('since', since);
    const qs = params.toString();
    return this.request(`/__admin/requests${qs ? '?' + qs : ''}`);
  }

  async deleteAllRequests(): Promise<void> {
    await this.request('/__admin/requests', { method: 'DELETE' });
  }

  async getUnmatchedRequests(): Promise<RequestJournalResponse> {
    // The unmatched endpoint returns bare LoggedRequest objects, whereas the
    // main journal endpoint returns ServeEvents ({ id, request, responseDefinition }).
    // Normalize to the ServeEvent shape the UI expects.
    const data = await this.request<{ requests?: unknown[]; meta?: { total: number } }>(
      '/__admin/requests/unmatched'
    );
    const raw = data.requests || [];
    const requests = raw.map((req, i) => {
      const r = req as { id?: string; loggedDate?: number } & Record<string, unknown>;
      // Unmatched requests carry no serve-event id; synthesize a stable-enough
      // one so React keys don't collide and rows stay distinct.
      return {
        id: r.id ?? `unmatched-${r.loggedDate ?? ''}-${i}`,
        request: r,
        responseDefinition: { status: 404, fromConfiguredStub: false },
      };
    }) as unknown as RequestJournalResponse['requests'];
    return { requests, meta: { total: data.meta?.total ?? requests.length } };
  }

  async deleteRequest(id: string): Promise<void> {
    await this.request(`/__admin/requests/${id}`, { method: 'DELETE' });
  }

  // Near Misses
  async getNearMissesForUnmatched(): Promise<NearMissesResponse> {
    return this.request('/__admin/requests/unmatched/near-misses');
  }

  // Scenarios
  async getAllScenarios(): Promise<ScenariosResponse> {
    return this.request('/__admin/scenarios');
  }

  async resetAllScenarios(): Promise<void> {
    await this.request('/__admin/scenarios/reset', { method: 'POST' });
  }

  async setScenarioState(scenarioName: string, state: string): Promise<void> {
    await this.request('/__admin/gui/api/set-scenario-state', {
      method: 'POST',
      body: JSON.stringify({ scenarioName, state }),
    });
  }

  // Recordings
  async getRecordingStatus(): Promise<RecordingStatus> {
    return this.request('/__admin/recordings/status');
  }

  async startRecording(targetBaseUrl: string): Promise<void> {
    await this.request('/__admin/recordings/start', {
      method: 'POST',
      body: JSON.stringify({ targetBaseUrl }),
    });
  }

  async stopRecording(): Promise<StubMappingsResponse> {
    return this.request('/__admin/recordings/stop', { method: 'POST' });
  }

  async snapshotRecording(): Promise<StubMappingsResponse> {
    return this.request('/__admin/recordings/snapshot', {
      method: 'POST',
      body: JSON.stringify({}),
    });
  }

  /** Retrieve every mapping, including when the server uses paginated responses. */
  async getAllStubMappingsForExport(): Promise<StubMapping[]> {
    const result: StubMapping[] = [];
    const pageSize = 100;
    let offset = 0;
    while (true) {
      const page = await this.getAllStubMappings(pageSize, offset);
      const items = page.mappings || [];
      result.push(...items);
      offset += items.length;
      if (!items.length || offset >= (page.meta?.total ?? offset)) break;
    }
    return result;
  }

  /** Fetch response body as bytes; text conversion corrupts binary responses. */
  async getFileBytes(filename: string): Promise<Uint8Array> {
    const headers: Record<string, string> = {};
    if (this.authToken) headers['Authorization'] = `Bearer ${this.authToken}`;
    const res = await fetch(`${this.baseUrl}/__admin/files/${encodeFilePath(filename)}`, { headers });
    if (res.status === 401) {
      window.dispatchEvent(new CustomEvent('wiremock-auth-expired'));
      throw new Error('Authentication required');
    }
    if (!res.ok) throw new Error(`Cannot download __files/${filename}: HTTP ${res.status}`);
    return new Uint8Array(await res.arrayBuffer());
  }

  async uploadFile(filename: string, bytes: Uint8Array): Promise<void> {
    const headers: Record<string, string> = { 'Content-Type': 'application/octet-stream' };
    if (this.authToken) headers['Authorization'] = `Bearer ${this.authToken}`;
    const res = await fetch(`${this.baseUrl}/__admin/files/${encodeFilePath(filename)}`, {
      method: 'PUT', headers, body: new Blob([bytes as BlobPart]),
    });
    if (res.status === 401) {
      window.dispatchEvent(new CustomEvent('wiremock-auth-expired'));
      throw new Error('Authentication required');
    }
    if (!res.ok) throw new Error(`Cannot upload __files/${filename}: HTTP ${res.status} ${await res.text()}`);
  }

  // Files
  async getAllFiles(): Promise<string[]> {
    return this.request('/__admin/files');
  }

  async getFile(filename: string): Promise<string> {
    const headers: Record<string, string> = {};
    if (this.authToken) headers['Authorization'] = `Bearer ${this.authToken}`;
    const res = await fetch(`${this.baseUrl}/__admin/files/${filename}`, { headers });
    if (res.status === 401) {
      window.dispatchEvent(new CustomEvent('wiremock-auth-expired'));
      throw new Error('Authentication required');
    }
    return res.text();
  }

  async updateFile(filename: string, content: string): Promise<void> {
    const headers: Record<string, string> = {};
    if (this.authToken) headers['Authorization'] = `Bearer ${this.authToken}`;
    const res = await fetch(`${this.baseUrl}/__admin/files/${filename}`, {
      method: 'PUT',
      headers,
      body: content,
    });
    if (res.status === 401) {
      window.dispatchEvent(new CustomEvent('wiremock-auth-expired'));
      throw new Error('Authentication required');
    }
  }

  async deleteFile(filename: string): Promise<void> {
    await this.request(`/__admin/files/${filename}`, { method: 'DELETE' });
  }

  // System
  async getHealth(): Promise<HealthResponse> {
    return this.request('/__admin/health');
  }

  async getVersion(): Promise<VersionResponse> {
    return this.request('/__admin/version');
  }

  async updateGlobalSettings(settings: Record<string, unknown>): Promise<void> {
    await this.request('/__admin/settings', {
      method: 'POST',
      body: JSON.stringify(settings),
    });
  }

  async resetAll(): Promise<void> {
    await this.request('/__admin/reset', { method: 'POST' });
  }

  async shutdown(): Promise<void> {
    await this.request('/__admin/shutdown', { method: 'POST' });
  }
}

/** Keep each directory segment encoded without changing the slash separators. */
function encodeFilePath(path: string): string {
  return path.split('/').map(encodeURIComponent).join('/');
}
