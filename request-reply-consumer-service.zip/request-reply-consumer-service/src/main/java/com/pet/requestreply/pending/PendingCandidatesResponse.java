package com.pet.requestreply.pending;
import java.util.List;
public record PendingCandidatesResponse(int page, int pageSize, long count, List<PendingCandidate> candidates) {}
