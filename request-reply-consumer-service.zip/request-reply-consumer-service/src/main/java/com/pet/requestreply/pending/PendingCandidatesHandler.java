package com.pet.requestreply.pending;

import com.pet.requestreply.handler.RequestHandler;
import com.pet.requestreply.model.PreparedRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PendingCandidatesHandler implements RequestHandler<PendingCandidatesRequest, PendingCandidatesResponse> {
    private final PendingCandidatesUseCase pendingCandidatesUseCase;

    @Override public String requestType(){ return "requisition_pending_candidates"; }
    @Override public Class<PendingCandidatesRequest> requestClass(){ return PendingCandidatesRequest.class; }

    @Override
    public PendingCandidatesResponse handle(PreparedRequest<PendingCandidatesRequest> request) {
        return pendingCandidatesUseCase.execute(request.systemParams(), request.payload());
    }
}
