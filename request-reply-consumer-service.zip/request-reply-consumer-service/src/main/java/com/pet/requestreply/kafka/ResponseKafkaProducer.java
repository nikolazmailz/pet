package com.pet.requestreply.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ResponseKafkaProducer {
    private final KafkaTemplate<String,String> kafkaTemplate;
    @Value("${app.kafka.response-topic}") private String responseTopic;
    public void send(String message){ kafkaTemplate.send(responseTopic, message); }
}
