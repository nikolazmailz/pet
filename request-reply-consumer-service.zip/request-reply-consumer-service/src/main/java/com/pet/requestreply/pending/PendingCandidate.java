package com.pet.requestreply.pending;
public record PendingCandidate(String candidateId, String fullName) {}
