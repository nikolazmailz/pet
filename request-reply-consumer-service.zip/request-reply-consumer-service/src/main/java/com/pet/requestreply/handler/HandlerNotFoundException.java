package com.pet.requestreply.handler;

public class HandlerNotFoundException extends RuntimeException {
    public HandlerNotFoundException(String requestType) {
        super("Handler not found for requestType: " + requestType);
    }
}
