package com.pet.requestreply.preparation;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pet.requestreply.model.PreparedRequest;
import com.pet.requestreply.model.RequestEntity;
import com.pet.requestreply.model.RequestEnvelope;
import com.pet.requestreply.model.SystemParams;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PreparedRequestService {
    private final ObjectMapper objectMapper;
    private final FileStorageService fileStorageService;
    private final RoleService roleService;
    private final StaffService staffService;
    private final RequestEntityService requestEntityService;

    public PreparedRequest<JsonNode> prepare(RequestEnvelope<JsonNode> envelope, String originalMessage) throws Exception {
        long start = System.currentTimeMillis();

        RequestEnvelope<JsonNode> request = restoreFromFilestorageIfNeeded(envelope);
        SystemParams systemParams = createSystemParams(request);
        setRequestContext(systemParams);
        logIncomingMessage(systemParams);
        RequestEntity requestEntity = saveRequest(systemParams, originalMessage);
        enrichRoles(systemParams, requestEntity);
        enrichTabNumber(systemParams, requestEntity);

        return new PreparedRequest<>(request, systemParams, requestEntity, start);
    }

    private RequestEnvelope<JsonNode> restoreFromFilestorageIfNeeded(RequestEnvelope<JsonNode> envelope) throws Exception {
        if (envelope.fileUuid() == null || envelope.fileUuid().isBlank()) return envelope;

        String storedMessage = fileStorageService.getMessage(
                envelope.adLogin(), envelope.sessionId(), envelope.traceId(), envelope.fileUuid()
        );
        JavaType type = objectMapper.getTypeFactory().constructParametricType(RequestEnvelope.class, JsonNode.class);
        return objectMapper.readValue(storedMessage, type);
    }

    private SystemParams createSystemParams(RequestEnvelope<?> request) {
        SystemParams p = new SystemParams();
        p.setCorrelationId(request.correlationId());
        p.setRequestType(request.requestType());
        p.setSessionId(request.sessionId());
        p.setAdLogin(request.adLogin());
        p.setTraceId(request.traceId());
        p.setChannel(request.channel());
        p.setRealm(request.realm());
        return p;
    }

    private void setRequestContext(SystemParams p) {
        RequestContextHolder.set(new RequestContext(p.getAdLogin(), p.getSessionId(), p.getChannel()));
    }

    private void logIncomingMessage(SystemParams p) {
        log.info("Kafka message received: requestType={}, correlationId={}, traceId={}", p.getRequestType(), p.getCorrelationId(), p.getTraceId());
    }

    private RequestEntity saveRequest(SystemParams p, String originalMessage) {
        return requestEntityService.save(p.getCorrelationId(), p.getSessionId(), originalMessage);
    }

    private void enrichRoles(SystemParams p, RequestEntity requestEntity) throws Exception {
        List<String> roles = roleService.getRoles(p.getAdLogin(), p.getChannel(), p.getSessionId(), p.getTraceId());
        if (roles == null || roles.isEmpty()) throw new IllegalStateException("Roles not found for user: " + p.getAdLogin());
        String role = roles.stream().max(Comparator.comparingInt(this::rolePriority)).orElseThrow();
        p.setRole(role);
        p.setRolesHeader(objectMapper.writeValueAsString(roles));
        requestEntityService.updateRole(p.getCorrelationId(), role);
    }

    private int rolePriority(String role) {
        return switch (role) {
            case "MSS_FULL" -> 400;
            case "MSS_STANDARD" -> 300;
            case "MSS_LIMITED" -> 200;
            case "ESS" -> 100;
            default -> 0;
        };
    }

    private void enrichTabNumber(SystemParams p, RequestEntity requestEntity) {
        String tabNumber = staffService.getTabNumber(p.getAdLogin(), p.getSessionId(), p.getTraceId());
        if (tabNumber == null || tabNumber.isBlank()) throw new IllegalStateException("Tab number not found for user: " + p.getAdLogin());
        p.setTabNumber(tabNumber);
        requestEntityService.updateTabNumber(p.getCorrelationId(), tabNumber);
    }
}
