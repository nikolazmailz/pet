package com.pet.requestreply.pending;

import com.pet.requestreply.model.SystemParams;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PendingCandidatesUseCase {
    public PendingCandidatesResponse execute(SystemParams systemParams, PendingCandidatesRequest request) {
        // Здесь только бизнес-логика. Kafka/JsonNode/resolver сюда не попадают.
        return new PendingCandidatesResponse(
                request.page(), request.pageSize(), 1,
                List.of(new PendingCandidate("candidate-1", "Demo Candidate"))
        );
    }
}
