package com.pet.requestreply.preparation;
public interface StaffService {
    String getTabNumber(String adLogin, String sessionId, String traceId);
}
