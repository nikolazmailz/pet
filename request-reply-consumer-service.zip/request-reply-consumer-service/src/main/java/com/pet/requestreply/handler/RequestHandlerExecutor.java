package com.pet.requestreply.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pet.requestreply.model.PreparedRequest;
import com.pet.requestreply.model.RequestEnvelope;
import com.pet.requestreply.model.ResponseEnvelope;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class RequestHandlerExecutor {
    private final ObjectMapper objectMapper;
    private final RequestHandlerResolver handlerResolver;

    public ResponseEnvelope<?> execute(PreparedRequest<JsonNode> preparedRequest) throws Exception {
        RequestHandler<?, ?> handler = handlerResolver.resolve(preparedRequest.requestType());
        return executeTyped(preparedRequest, handler);
    }

    private <T,R> ResponseEnvelope<R> executeTyped(
            PreparedRequest<JsonNode> preparedRequest,
            RequestHandler<T,R> handler
    ) throws Exception {
        T payload = objectMapper.treeToValue(preparedRequest.payload(), handler.requestClass());

        RequestEnvelope<T> typedEnvelope = new RequestEnvelope<>(
                preparedRequest.envelope().correlationId(),
                preparedRequest.envelope().requestType(),
                preparedRequest.envelope().sessionId(),
                preparedRequest.envelope().adLogin(),
                preparedRequest.envelope().traceId(),
                preparedRequest.envelope().channel(),
                preparedRequest.envelope().realm(),
                preparedRequest.envelope().fileUuid(),
                payload
        );

        PreparedRequest<T> typedRequest = new PreparedRequest<>(
                typedEnvelope,
                preparedRequest.systemParams(),
                preparedRequest.requestEntity(),
                preparedRequest.startedAt()
        );

        R result = handler.handle(typedRequest);
        return ResponseEnvelope.success(typedRequest.correlationId(), typedRequest.requestType(), result);
    }
}
