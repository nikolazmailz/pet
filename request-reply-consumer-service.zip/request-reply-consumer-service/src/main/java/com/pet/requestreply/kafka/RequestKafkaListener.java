package com.pet.requestreply.kafka;

import com.pet.requestreply.preparation.RequestContextHolder;
import com.pet.requestreply.processing.MessageProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class RequestKafkaListener {
    private final MessageProcessor messageProcessor;
    private final ResponseKafkaProducer responseKafkaProducer;

    @KafkaListener(topics = "${app.kafka.request-topic}", groupId = "${spring.kafka.consumer.group-id}")
    public void listen(String message, Acknowledgment ack) {
        try {
            String response = messageProcessor.processMessage(message);
            responseKafkaProducer.send(response);
            ack.acknowledge();
        } catch (Exception e) {
            log.error("Failed to process Kafka message", e);
            ack.acknowledge();
        } finally {
            RequestContextHolder.clear();
        }
    }
}
