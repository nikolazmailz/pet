package com.pet.requestreply.preparation;

import com.pet.requestreply.model.RequestEntity;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Configuration
public class DemoInfrastructureConfig {
    @Bean RoleService roleService() { return (a,c,s,t) -> List.of("MSS_STANDARD"); }
    @Bean StaffService staffService() { return (a,s,t) -> "000001"; }
    @Bean FileStorageService fileStorageService() { return (a,s,t,f) -> { throw new IllegalStateException("Configure real filestorage for fileUuid="+f); }; }
    @Bean RequestEntityService requestEntityService() {
        AtomicLong seq = new AtomicLong();
        return new RequestEntityService() {
            public RequestEntity save(String c,String s,String m){ return new RequestEntity(seq.incrementAndGet(),c,m,null,null,"SENT"); }
            public void updateRole(String c,String r){}
            public void updateTabNumber(String c,String t){}
        };
    }
}
