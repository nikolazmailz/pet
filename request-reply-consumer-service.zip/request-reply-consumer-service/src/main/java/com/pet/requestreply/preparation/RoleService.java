package com.pet.requestreply.preparation;
import java.util.List;
public interface RoleService {
    List<String> getRoles(String adLogin, String channel, String sessionId, String traceId);
}
