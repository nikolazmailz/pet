package com.pet.requestreply.processing;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pet.requestreply.handler.RequestHandlerExecutor;
import com.pet.requestreply.model.PreparedRequest;
import com.pet.requestreply.model.RequestEnvelope;
import com.pet.requestreply.model.ResponseEnvelope;
import com.pet.requestreply.preparation.PreparedRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MessageProcessor {
    private final ObjectMapper objectMapper;
    private final PreparedRequestService preparedRequestService;
    private final RequestHandlerExecutor requestHandlerExecutor;

    public String processMessage(String messageIncoming) throws Exception {
        RequestEnvelope<JsonNode> envelope = deserialize(messageIncoming);
        PreparedRequest<JsonNode> preparedRequest = preparedRequestService.prepare(envelope, messageIncoming);
        ResponseEnvelope<?> response = requestHandlerExecutor.execute(preparedRequest);
        return objectMapper.writeValueAsString(response);
    }

    private RequestEnvelope<JsonNode> deserialize(String messageIncoming) throws Exception {
        JavaType type = objectMapper.getTypeFactory().constructParametricType(RequestEnvelope.class, JsonNode.class);
        return objectMapper.readValue(messageIncoming, type);
    }
}
