package com.pet.requestreply.preparation;
public interface FileStorageService {
    String getMessage(String adLogin, String sessionId, String traceId, String fileUuid);
}
