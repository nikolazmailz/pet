package com.pet.requestreply.preparation;
public record RequestContext(String adLogin, String sessionId, String channel) {}
