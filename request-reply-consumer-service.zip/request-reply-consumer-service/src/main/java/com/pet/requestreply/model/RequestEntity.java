package com.pet.requestreply.model;

public record RequestEntity(
        Long id,
        String correlationId,
        String requestBody,
        String role,
        String tabNumber,
        String status
) {}
