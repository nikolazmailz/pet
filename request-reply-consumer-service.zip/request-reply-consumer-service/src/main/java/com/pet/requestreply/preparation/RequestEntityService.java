package com.pet.requestreply.preparation;
import com.pet.requestreply.model.RequestEntity;
public interface RequestEntityService {
    RequestEntity save(String correlationId, String sessionId, String originalMessage);
    void updateRole(String correlationId, String role);
    void updateTabNumber(String correlationId, String tabNumber);
}
