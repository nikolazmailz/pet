# Consumer service demo

Показывает только второй сервис и путь:

Kafka -> RequestKafkaListener -> MessageProcessor.processMessage(String) ->
PreparedRequestService -> RequestHandlerExecutor -> RequestHandlerResolver ->
PendingCandidatesHandler -> PendingCandidatesUseCase -> ResponseEnvelope -> Kafka.

`PreparedRequestService` содержит общую часть, которая раньше находилась в
`processMessage()` до `switch(requestType)`:

- restoreFromFilestorageIfNeeded
- createSystemParams
- setRequestContext
- logIncomingMessage
- saveRequest
- enrichRoles
- enrichTabNumber

В `DemoInfrastructureConfig` стоят заглушки вместо SRHR сервисов. В реальном проекте
их нужно заменить на `FilestorageService`, `TsrmIntegrationService`,
`BscsIntegrationService`, `EntityServiceImpl`, а `SystemParams/RequestEntity` — на
`SapSystemParamsDto/RequisitionRequestEntity`.
