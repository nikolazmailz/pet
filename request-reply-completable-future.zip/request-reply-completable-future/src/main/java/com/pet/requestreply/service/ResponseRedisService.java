package com.pet.requestreply.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

@Service
public class ResponseRedisService {

    private static final String PREFIX = "request-reply:response:";

    private final StringRedisTemplate redisTemplate;
    private final Duration ttl;

    public ResponseRedisService(
            StringRedisTemplate redisTemplate,
            @Value("${app.request-reply.response-ttl-seconds:60}") long ttlSeconds
    ) {
        this.redisTemplate = redisTemplate;
        this.ttl = Duration.ofSeconds(ttlSeconds);
    }

    public void save(String correlationId, String response) {
        redisTemplate.opsForValue().set(key(correlationId), response, ttl);
    }

    public String get(String correlationId) {
        return redisTemplate.opsForValue().get(key(correlationId));
    }

    public void delete(String correlationId) {
        redisTemplate.delete(key(correlationId));
    }

    private String key(String correlationId) {
        return PREFIX + correlationId;
    }
}
