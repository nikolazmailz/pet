package com.pet.requestreply.service;

import org.springframework.stereotype.Component;

@Component
public class ResponseNotificationSubscriber {

    private final PendingResponseRegistry registry;
    private final ResponseRedisService redisService;

    public ResponseNotificationSubscriber(
            PendingResponseRegistry registry,
            ResponseRedisService redisService
    ) {
        this.registry = registry;
        this.redisService = redisService;
    }

    public void onMessage(String correlationId) {
        if (!registry.contains(correlationId)) {
            return;
        }

        String response = redisService.get(correlationId);
        if (response == null) {
            return;
        }

        registry.complete(correlationId, response);
        redisService.delete(correlationId);
    }
}
