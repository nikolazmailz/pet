package com.pet.requestreply.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class RequestReplyService {

    private final PendingResponseRegistry registry;
    private final RequestSender requestSender;
    private final ResponseRedisService redisService;
    private final long timeoutMs;

    public RequestReplyService(
            PendingResponseRegistry registry,
            RequestSender requestSender,
            ResponseRedisService redisService,
            @Value("${app.request-reply.timeout-ms:10000}") long timeoutMs
    ) {
        this.registry = registry;
        this.requestSender = requestSender;
        this.redisService = redisService;
        this.timeoutMs = timeoutMs;
    }

    public String getResponse(String correlationId, String message) throws Exception {
        CompletableFuture<String> future = registry.register(correlationId);

        try {
            requestSender.send(correlationId, message);

            String alreadyStored = redisService.get(correlationId);
            if (alreadyStored != null) {
                registry.complete(correlationId, alreadyStored);
                redisService.delete(correlationId);
            }

            return future.get(timeoutMs, TimeUnit.MILLISECONDS);

        } catch (TimeoutException e) {
            throw new RequestReplyTimeoutException(correlationId, timeoutMs);
        } finally {
            registry.remove(correlationId);
        }
    }
}
