package com.pet.requestreply.service;

public class RequestReplyTimeoutException extends RuntimeException {
    public RequestReplyTimeoutException(String correlationId, long timeoutMs) {
        super("Response timeout. correlationId=" + correlationId + ", timeoutMs=" + timeoutMs);
    }
}
