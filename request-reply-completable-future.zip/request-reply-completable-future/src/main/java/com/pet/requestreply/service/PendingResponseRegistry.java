package com.pet.requestreply.service;

import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Component
public class PendingResponseRegistry {

    private final ConcurrentMap<String, CompletableFuture<String>> pending = new ConcurrentHashMap<>();

    public CompletableFuture<String> register(String correlationId) {
        CompletableFuture<String> future = new CompletableFuture<>();
        CompletableFuture<String> previous = pending.putIfAbsent(correlationId, future);

        if (previous != null) {
            throw new IllegalStateException("Request already registered: " + correlationId);
        }

        return future;
    }

    public void complete(String correlationId, String response) {
        CompletableFuture<String> future = pending.remove(correlationId);
        if (future != null) {
            future.complete(response);
        }
    }

    public boolean contains(String correlationId) {
        return pending.containsKey(correlationId);
    }

    public void remove(String correlationId) {
        pending.remove(correlationId);
    }
}
