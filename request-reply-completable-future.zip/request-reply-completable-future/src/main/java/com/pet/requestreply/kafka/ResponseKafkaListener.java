package com.pet.requestreply.kafka;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pet.requestreply.service.ResponseNotificationPublisher;
import com.pet.requestreply.service.ResponseRedisService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class ResponseKafkaListener {

    private final ObjectMapper objectMapper;
    private final ResponseRedisService redisService;
    private final ResponseNotificationPublisher publisher;

    public ResponseKafkaListener(
            ObjectMapper objectMapper,
            ResponseRedisService redisService,
            ResponseNotificationPublisher publisher
    ) {
        this.objectMapper = objectMapper;
        this.redisService = redisService;
        this.publisher = publisher;
    }

    @KafkaListener(topics = "${app.kafka.response-topic}")
    public void listen(String data) throws Exception {
        JsonNode json = objectMapper.readTree(data);
        String correlationId = json.get("correlationId").asText();

        // 1. Сначала сохраняем сам ответ.
        redisService.save(correlationId, data);

        // 2. Потом публикуем только сигнал о готовности.
        publisher.publish(correlationId);
    }
}
