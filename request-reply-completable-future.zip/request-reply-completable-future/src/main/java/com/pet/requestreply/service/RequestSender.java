package com.pet.requestreply.service;

public interface RequestSender {
    void send(String correlationId, String message);
}
