package com.pet.requestreply.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class ResponseNotificationPublisher {

    private final StringRedisTemplate redisTemplate;
    private final String channel;

    public ResponseNotificationPublisher(
            StringRedisTemplate redisTemplate,
            @Value("${app.request-reply.pubsub-channel:request-reply-response}") String channel
    ) {
        this.redisTemplate = redisTemplate;
        this.channel = channel;
    }

    public void publish(String correlationId) {
        redisTemplate.convertAndSend(channel, correlationId);
    }
}
