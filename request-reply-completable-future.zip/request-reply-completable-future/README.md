# CompletableFuture + Redis Pub/Sub

Схема для нескольких pod:

1. Pod, принявший REST-запрос, создаёт локальный `CompletableFuture` по `correlationId`.
2. Запрос отправляется дальше текущим `RequestSender`.
3. Kafka response может получить любой pod.
4. Kafka listener сначала сохраняет ответ в Redis.
5. Затем публикует `correlationId` в Redis Pub/Sub.
6. Все pod получают сигнал, но только pod с локальным future для этого `correlationId` читает Redis.
7. Он вызывает `future.complete(response)`.
8. `getResponse()` продолжает выполнение без polling и `Thread.sleep(50)`.

Важно: реализацию `RequestSender` подключи к текущему `redisAdapter.putToQueue(...)` или Kafka producer.
