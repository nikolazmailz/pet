# Consumer service — Clean Architecture

## Dependency direction

`infrastructure -> application`

`application` does not import Spring, Kafka or Jackson.

## Main flow

Kafka listener (infrastructure)
→ MessageProcessingService.processMessage(String) (application)
→ PreparedRequestService
→ RequestHandlerExecutor / Resolver
→ PendingCandidatesHandler
→ PendingCandidatesUseCase
→ ResponseEnvelope
→ Kafka producer (infrastructure)

## Packages

- `application/model` — RequestEnvelope, PreparedRequest, SystemParams
- `application/port/out` — contracts for filestorage, roles, staff, persistence, context, codec
- `application/service` — orchestration and common preparation
- `application/handler` — generic dispatch instead of switch
- `application/usecase` — concrete business cases
- `infrastructure/kafka` — Kafka listener/producer
- `infrastructure/json` — Jackson implementation of MessageCodecPort
- `infrastructure/context` — ThreadLocal context
- `infrastructure/adapter` — demo external adapters
- `infrastructure/config` — Spring wiring

`PreparedRequestService` is the common block that replaces everything before the old `switch(requestType)`.
`RequestHandler` replaces each case of that switch.
`UseCase` contains only business logic.
