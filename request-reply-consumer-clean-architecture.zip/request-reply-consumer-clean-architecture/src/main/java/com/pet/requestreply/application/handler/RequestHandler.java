package com.pet.requestreply.application.handler;
import com.pet.requestreply.application.model.PreparedRequest;

public interface RequestHandler<T, R> {
    String requestType();
    Class<T> requestClass();
    R handle(PreparedRequest<T> request) throws Exception;
}
