package com.pet.requestreply.infrastructure.logging;

import com.pet.requestreply.application.model.SystemParams;
import com.pet.requestreply.application.port.out.RequestLogPort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Slf4jRequestLogAdapter implements RequestLogPort {
    private static final Logger log = LoggerFactory.getLogger(Slf4jRequestLogAdapter.class);

    @Override
    public void messageReceived(SystemParams p) {
        log.info(
                "Kafka message received requestType={}, correlationId={}, sessionId={}, traceId={}",
                p.getRequestType(),
                p.getCorrelationId(),
                p.getSessionId(),
                p.getTraceId()
        );
    }
}
