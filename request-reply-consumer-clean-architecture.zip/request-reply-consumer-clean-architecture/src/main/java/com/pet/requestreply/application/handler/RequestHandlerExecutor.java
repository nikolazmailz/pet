package com.pet.requestreply.application.handler;

import com.pet.requestreply.application.model.*;
import com.pet.requestreply.application.port.out.MessageCodecPort;

public class RequestHandlerExecutor {
    private final MessageCodecPort codec;
    private final RequestHandlerResolver resolver;

    public RequestHandlerExecutor(MessageCodecPort codec, RequestHandlerResolver resolver) {
        this.codec = codec;
        this.resolver = resolver;
    }

    public ResponseEnvelope<?> execute(PreparedRequest<RawPayload> prepared) throws Exception {
        return executeTyped(prepared, resolver.resolve(prepared.requestType()));
    }

    private <T, R> ResponseEnvelope<R> executeTyped(
            PreparedRequest<RawPayload> prepared,
            RequestHandler<T, R> handler
    ) throws Exception {
        T payload = codec.deserializePayload(prepared.payload(), handler.requestClass());

        RequestEnvelope<T> typedEnvelope = new RequestEnvelope<>(
                prepared.envelope().correlationId(),
                prepared.envelope().requestType(),
                prepared.envelope().sessionId(),
                prepared.envelope().adLogin(),
                prepared.envelope().traceId(),
                prepared.envelope().channel(),
                prepared.envelope().realm(),
                prepared.envelope().fileUuid(),
                payload
        );

        PreparedRequest<T> typed = new PreparedRequest<>(
                typedEnvelope,
                prepared.systemParams(),
                prepared.requestRecord(),
                prepared.startedAt()
        );

        R result = handler.handle(typed);

        return ResponseEnvelope.success(
                typed.correlationId(),
                typed.requestType(),
                result
        );
    }
}
