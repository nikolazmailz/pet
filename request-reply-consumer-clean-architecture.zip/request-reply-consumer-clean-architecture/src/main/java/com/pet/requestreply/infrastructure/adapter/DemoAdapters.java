package com.pet.requestreply.infrastructure.adapter;

import com.pet.requestreply.application.model.RequestRecord;
import com.pet.requestreply.application.port.out.*;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public final class DemoAdapters {
    private DemoAdapters() {}

    public static class FileStorage implements FileStoragePort {
        @Override
        public String getMessage(String adLogin, String sessionId, String traceId, String fileUuid) {
            throw new IllegalStateException("Replace demo filestorage adapter. fileUuid=" + fileUuid);
        }
    }

    public static class Roles implements RolePort {
        @Override
        public List<String> getRoles(String adLogin, String channel, String sessionId, String traceId) {
            return List.of("MSS_STANDARD");
        }
    }

    public static class Staff implements StaffPort {
        @Override
        public String getTabNumber(String adLogin, String sessionId, String traceId) {
            return "000001";
        }
    }

    public static class Requests implements RequestRepositoryPort {
        private final AtomicLong sequence = new AtomicLong();

        @Override
        public RequestRecord save(String correlationId, String sessionId, String originalMessage) {
            return new RequestRecord(sequence.incrementAndGet(), correlationId, "SENT");
        }

        @Override
        public void updateRole(String correlationId, String role) {}

        @Override
        public void updateTabNumber(String correlationId, String tabNumber) {}
    }
}
