package com.pet.requestreply.application.model;
public record RequestRecord(Long id, String correlationId, String status) {}
