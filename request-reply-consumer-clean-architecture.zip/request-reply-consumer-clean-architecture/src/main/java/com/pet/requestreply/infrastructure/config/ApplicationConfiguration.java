package com.pet.requestreply.infrastructure.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pet.requestreply.application.handler.*;
import com.pet.requestreply.application.port.out.*;
import com.pet.requestreply.application.service.*;
import com.pet.requestreply.application.usecase.pending.*;
import com.pet.requestreply.infrastructure.adapter.DemoAdapters;
import com.pet.requestreply.infrastructure.context.ThreadLocalRequestContextAdapter;
import com.pet.requestreply.infrastructure.json.JacksonMessageCodecAdapter;
import com.pet.requestreply.infrastructure.kafka.*;
import com.pet.requestreply.infrastructure.logging.Slf4jRequestLogAdapter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.List;

@Configuration
public class ApplicationConfiguration {

    @Bean
    MessageCodecPort messageCodec(ObjectMapper mapper) {
        return new JacksonMessageCodecAdapter(mapper);
    }

    @Bean FileStoragePort fileStoragePort() { return new DemoAdapters.FileStorage(); }
    @Bean RolePort rolePort() { return new DemoAdapters.Roles(); }
    @Bean StaffPort staffPort() { return new DemoAdapters.Staff(); }
    @Bean RequestRepositoryPort requestRepositoryPort() { return new DemoAdapters.Requests(); }
    @Bean RequestContextPort requestContextPort() { return new ThreadLocalRequestContextAdapter(); }
    @Bean RequestLogPort requestLogPort() { return new Slf4jRequestLogAdapter(); }

    @Bean
    PendingCandidatesUseCase pendingCandidatesUseCase() {
        return new PendingCandidatesUseCase();
    }

    @Bean
    PendingCandidatesHandler pendingCandidatesHandler(PendingCandidatesUseCase useCase) {
        return new PendingCandidatesHandler(useCase);
    }

    @Bean
    RequestHandlerResolver requestHandlerResolver(List<RequestHandler<?, ?>> handlers) {
        return new RequestHandlerResolver(handlers);
    }

    @Bean
    RequestHandlerExecutor requestHandlerExecutor(
            MessageCodecPort codec,
            RequestHandlerResolver resolver
    ) {
        return new RequestHandlerExecutor(codec, resolver);
    }

    @Bean
    PreparedRequestService preparedRequestService(
            MessageCodecPort codec,
            FileStoragePort fileStorage,
            RolePort roles,
            StaffPort staff,
            RequestRepositoryPort repository,
            RequestContextPort context,
            RequestLogPort log
    ) {
        return new PreparedRequestService(
                codec, fileStorage, roles, staff, repository, context, log
        );
    }

    @Bean
    MessageProcessingService messageProcessingService(
            MessageCodecPort codec,
            PreparedRequestService prepared,
            RequestHandlerExecutor executor
    ) {
        return new MessageProcessingService(codec, prepared, executor);
    }

    @Bean
    ResponseKafkaProducer responseKafkaProducer(
            KafkaTemplate<String, String> kafkaTemplate,
            @Value("${app.kafka.response-topic}") String topic
    ) {
        return new ResponseKafkaProducer(kafkaTemplate, topic);
    }

    @Bean
    RequestKafkaListener requestKafkaListener(
            MessageProcessingService processing,
            ResponseKafkaProducer producer,
            MessageCodecPort codec,
            RequestContextPort context
    ) {
        return new RequestKafkaListener(processing, producer, codec, context);
    }
}
