package com.pet.requestreply;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestReplyConsumerApplication {
    public static void main(String[] args) {
        SpringApplication.run(RequestReplyConsumerApplication.class, args);
    }
}
