package com.pet.requestreply.application.model;

public record ResponseEnvelope<T>(
        String correlationId,
        String requestType,
        T payload,
        ErrorInfo error
) {
    public static <T> ResponseEnvelope<T> success(String correlationId, String requestType, T payload) {
        return new ResponseEnvelope<>(correlationId, requestType, payload, null);
    }

    public static ResponseEnvelope<Void> error(String correlationId, String requestType, String code, String message) {
        return new ResponseEnvelope<>(correlationId, requestType, null, new ErrorInfo(code, message));
    }

    public record ErrorInfo(String code, String message) {}
}
