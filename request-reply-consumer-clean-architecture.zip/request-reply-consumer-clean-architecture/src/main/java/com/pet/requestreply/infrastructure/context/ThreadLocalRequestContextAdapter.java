package com.pet.requestreply.infrastructure.context;

import com.pet.requestreply.application.port.out.RequestContextPort;

public class ThreadLocalRequestContextAdapter implements RequestContextPort {
    private static final ThreadLocal<Context> HOLDER = new ThreadLocal<>();

    @Override
    public void set(String adLogin, String sessionId, String channel) {
        HOLDER.set(new Context(adLogin, sessionId, channel));
    }

    @Override
    public void clear() {
        HOLDER.remove();
    }

    public static Context current() {
        return HOLDER.get();
    }

    public record Context(String adLogin, String sessionId, String channel) {}
}
