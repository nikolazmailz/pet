package com.pet.requestreply.application.model;
public record RawPayload(String value) {}
