package com.pet.requestreply.application.model;

public class SystemParams {
    private String correlationId;
    private String requestType;
    private String sessionId;
    private String adLogin;
    private String traceId;
    private String channel;
    private String realm;
    private String role;
    private String rolesHeader;
    private String tabNumber;

    public String getCorrelationId() { return correlationId; }
    public void setCorrelationId(String v) { correlationId = v; }
    public String getRequestType() { return requestType; }
    public void setRequestType(String v) { requestType = v; }
    public String getSessionId() { return sessionId; }
    public void setSessionId(String v) { sessionId = v; }
    public String getAdLogin() { return adLogin; }
    public void setAdLogin(String v) { adLogin = v; }
    public String getTraceId() { return traceId; }
    public void setTraceId(String v) { traceId = v; }
    public String getChannel() { return channel; }
    public void setChannel(String v) { channel = v; }
    public String getRealm() { return realm; }
    public void setRealm(String v) { realm = v; }
    public String getRole() { return role; }
    public void setRole(String v) { role = v; }
    public String getRolesHeader() { return rolesHeader; }
    public void setRolesHeader(String v) { rolesHeader = v; }
    public String getTabNumber() { return tabNumber; }
    public void setTabNumber(String v) { tabNumber = v; }
}
