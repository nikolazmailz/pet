package com.pet.requestreply.infrastructure.json;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pet.requestreply.application.model.*;
import com.pet.requestreply.application.port.out.MessageCodecPort;

public class JacksonMessageCodecAdapter implements MessageCodecPort {
    private final ObjectMapper objectMapper;

    public JacksonMessageCodecAdapter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public RequestEnvelope<RawPayload> deserializeRequest(String message) throws Exception {
        JsonNode root = objectMapper.readTree(message);
        JsonNode payloadNode = root.get("payload");

        RawPayload payload =
                payloadNode == null || payloadNode.isNull()
                        ? null
                        : new RawPayload(objectMapper.writeValueAsString(payloadNode));

        return new RequestEnvelope<>(
                text(root, "correlationId"),
                text(root, "requestType"),
                text(root, "sessionId"),
                text(root, "adLogin"),
                text(root, "traceId"),
                text(root, "channel"),
                text(root, "realm"),
                text(root, "fileUuid"),
                payload
        );
    }

    @Override
    public <T> T deserializePayload(RawPayload payload, Class<T> type) throws Exception {
        if (payload == null) {
            return null;
        }
        return objectMapper.readValue(payload.value(), type);
    }

    @Override
    public String serializeResponse(ResponseEnvelope<?> response) throws Exception {
        return objectMapper.writeValueAsString(response);
    }

    @Override
    public String serializeObject(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    private String text(JsonNode root, String field) {
        JsonNode value = root.get(field);
        return value == null || value.isNull() ? null : value.asText();
    }
}
