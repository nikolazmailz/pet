package com.pet.requestreply.infrastructure.kafka;

import com.pet.requestreply.application.model.*;
import com.pet.requestreply.application.port.out.MessageCodecPort;
import com.pet.requestreply.application.port.out.RequestContextPort;
import com.pet.requestreply.application.service.MessageProcessingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;

public class RequestKafkaListener {
    private static final Logger log = LoggerFactory.getLogger(RequestKafkaListener.class);

    private final MessageProcessingService processingService;
    private final ResponseKafkaProducer producer;
    private final MessageCodecPort codec;
    private final RequestContextPort context;

    public RequestKafkaListener(
            MessageProcessingService processingService,
            ResponseKafkaProducer producer,
            MessageCodecPort codec,
            RequestContextPort context
    ) {
        this.processingService = processingService;
        this.producer = producer;
        this.codec = codec;
        this.context = context;
    }

    @KafkaListener(
            topics = "${app.kafka.request-topic}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void listen(String message, Acknowledgment ack) {
        try {
            producer.send(processingService.processMessage(message));
            ack.acknowledge();
        } catch (Exception e) {
            log.error("Kafka request processing failed", e);
            sendErrorIfPossible(message, e);
            ack.acknowledge();
        } finally {
            context.clear();
        }
    }

    private void sendErrorIfPossible(String message, Exception e) {
        try {
            RequestEnvelope<RawPayload> envelope = codec.deserializeRequest(message);
            ResponseEnvelope<Void> error = ResponseEnvelope.error(
                    envelope.correlationId(),
                    envelope.requestType(),
                    "500",
                    e.getMessage()
            );
            producer.send(codec.serializeResponse(error));
        } catch (Exception errorException) {
            log.error("Could not send error response", errorException);
        }
    }
}
